"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const fs = require('fs');
const { typeToCode } = require('tuzirobot/commonUtil');
exports.config = {
    name: 'flowControl.if',
    key: 'flowControl.test',
    displayName: 'IF 条件',
    icon: 'icon-web-create',
    sort: 10,
    isControl: true,
    isControlEnd: false,
    comment: '判断${operand1} ${operator} ${operand2} 是否成立，如果成立，则执行以下操作',
    inputs: {
        operand1: {
            name: '条件操作数1',
            value: '',
            type: 'string',
            addConfig: {
                required: true,
                type: 'string',
                label: '对象1'
            }
        },
        operator: {
            name: '关系',
            value: '==',
            display: '等于',
            type: 'string',
            addConfig: {
                type: 'select',
                label: '关系',
                required: true,
                options: [
                    { value: '==', label: '等于' },
                    { value: '!=', label: '不等于' },
                    { value: '>', label: '大于' },
                    { value: '<', label: '小于' },
                    { value: '>=', label: '大于等于' },
                    { value: '<=', label: '小于等于' },
                    { value: 'in', label: '包含' },
                    { value: 'notin', label: '不包含' },
                    { value: 'isTrue', label: '等于true' },
                    { value: 'noTrue', label: '不等true' },
                    { value: 'isNull', label: '是空值' },
                    { value: 'noNull', label: '不是空值' }
                ],
                defaultValue: '=='
            }
        },
        operand2: {
            name: '条件操作数2',
            value: '',
            type: 'string',
            addConfig: {
                type: 'string',
                label: '对象2',
                /**
                 * { value: 'isTrue', label: '等于true' },
                    { value: 'noTrue', label: '不等true' },
                    { value: 'isNull', label: '是空值' },
                    { value: 'noNull', label: '不是空值' }
                 */
                filters: `!(this.inputs.operator.value === 'isTrue' || this.inputs.operator.value === 'noTrue' || this.inputs.operator.value === 'isNull' || this.inputs.operator.value === 'noNull')`
            }
        }
    },
    outputs: {},
    toCode(directive, block) {
        return __awaiter(this, void 0, void 0, function* () {
            const { operand1, operator, operand2 } = directive.inputs;
            return `if (await robotUtil.system.flowControl.test( ${typeToCode(operand1)}, '${operator.value}',${typeToCode(operand2)},${block})) {`;
        });
    }
};
exports.impl = function (operand1, operator, operand2) {
    return __awaiter(this, void 0, void 0, function* () {
        /**
         *
            { value: 'in', label: '包含' },
            { value: 'notin', label: '不包含' },
            { value: 'isTrue', label: '等于true' },
            { value: 'noTrue', label: '不等true' },
            { value: 'isNull', label: '是空值' },
            { value: 'noNull', label: '不是空值' }
         */
        if (operator === 'isNull') {
            console.log('isNull', operand1);
            return operand1 === null || operand1 === '';
        }
        else if (operator === 'noNull') {
            return operand1 !== null && operand1 !== '';
        }
        else if (operator === 'isTrue') {
            return operand1 === true;
        }
        else if (operator === 'noTrue') {
            return operand1 !== true;
        }
        else if (operator === 'in') {
            return operand1.includes(operand2);
        }
        else if (operator === 'notin') {
            return !operand1.includes(operand2);
        }
        else if (operator === '==') {
            return operand1 == operand2;
        }
        else if (operator === '!=') {
            return operand1 != operand2;
        }
        else if (operator === '>') {
            return Number(operand1) > Number(operand2);
        }
        else if (operator === '<') {
            return Number(operand1) < Number(operand2);
        }
        else if (operator === '>=') {
            return Number(operand1) >= Number(operand2);
        }
        else if (operator === '<=') {
            return Number(operand1) <= Number(operand2);
        }
        // const result = eval(`'${operand1}'${operator}'${operand2}'`);
        return false;
    });
};
