"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const fs = require("fs");
exports.config = {
    name: 'flowControl.continue',
    displayName: '继续下一次循环',
    icon: 'icon-web-create',
    isControl: false,
    sort: 32,
    isControlEnd: false,
    comment: '忽略本次循环，继续下一次循环',
    inputs: {},
    outputs: {},
    toCode(_directive, _block) {
        return __awaiter(this, void 0, void 0, function* () {
            return `continue;`;
        });
    }
};
exports.impl = function () {
    return __awaiter(this, void 0, void 0, function* () {
    });
};
