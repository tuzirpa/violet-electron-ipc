"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "flowControl.delayed",
    displayName: "延时等待",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "延时等待，单位：${loadTimeout}秒",
    inputs: {
        loadTimeout: {
            name: "timeout",
            value: "30",
            type: "number",
            addConfig: {
                label: "超时",
                type: "string",
                required: true,
                defaultValue: "30",
                tip: "延时等待时间，单位：秒",
            },
        },
    },
    outputs: {},
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ loadTimeout }) {
        console.log(`延时等待${loadTimeout}秒`);
        yield new Promise((resolve) => {
            setTimeout(() => {
                resolve(null);
            }, loadTimeout * 1000);
        });
    });
};
exports.impl = impl;
