"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
const fs = require("fs");
exports.config = {
    name: "dataProcessing.jsonLogPrint",
    displayName: "JSON对象打印",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "输出日志 ${content}",
    inputs: {
        content: {
            name: "要输出的内容",
            value: "",
            type: "variable",
            addConfig: {
                label: "输出内容",
                type: "variable",
                defaultValue: "test",
                tip: "输出内容",
            },
        },
    },
    outputs: {},
};
const convertMapToObject = (map) => {
    const obj = {};
    for (const [key, value] of map.entries()) {
        obj[key] = ((value) => {
            if (value instanceof Map) {
                return convertMapToObject(value);
            }
            return value;
        })(value);
    }
    return obj;
};
exports.impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ content }) {
        if (content instanceof Map) {
            content = convertMapToObject(content);
        }
        console.log(content.toString());
        console.log(JSON.stringify(content, null, 2));
    });
};
