"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'dataProcessing.map.keyGetValue',
    displayName: '获取Map指定元素',
    comment: '设置Map存储数据，将数据存入${mapObj}对象中,key为${key},value为${value}',
    inputs: {
        mapObj: {
            name: 'mapObj',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                required: true,
                label: 'Map对象',
                placeholder: '选择Map对象',
                type: 'variable',
                filtersType: 'map',
                autoComplete: true
            }
        },
        key: {
            name: 'key',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                label: '数据key',
                placeholder: '数据key',
                type: 'string',
                autoComplete: true
            }
        }
    },
    outputs: {
        mapValue: {
            name: 'mapValue',
            display: '返回Map的Value',
            type: 'variable',
            addConfig: {
                label: '返回Map的Value',
                type: 'variable',
                defaultValue: ''
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ mapObj, key }) {
        return { mapValue: mapObj.get(key) };
    });
};
exports.impl = impl;
