"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const fs = require("fs");
const { typeToCode } = require("tuzirobot/commonUtil");
exports.config = {
    name: "dataProcessing.modificationVariable",
    displayName: "修改变量",
    isControl: false,
    isControlEnd: false,
    comment: "修改变量 ${varKey} 值为 ${varValue}",
    inputs: {
        varValue: {
            name: "变量值",
            value: "",
            type: "string",
            addConfig: {
                label: "变量值",
                type: "string",
                defaultValue: "",
            },
        },
    },
    outputs: {
        varKey: {
            name: "",
            type: "string",
            display: "",
            addConfig: {
                label: "要修改的变量",
                type: "variable",
            },
        },
    },
    toCode(directive, block) {
        return __awaiter(this, void 0, void 0, function* () {
            const name = directive.outputs.varKey.name;
            let varValue = directive.inputs.varValue;
            return `${name} = await robotUtil.system.dataProcessing.modificationVariable({"varValue": ${typeToCode(varValue)}},${block});`;
        });
    },
};
exports.impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ varValue }) {
        return varValue;
    });
};
