"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const commonUtil_1 = require("tuzirobot/commonUtil");
exports.config = {
    name: 'dataProcessing.modificationVariable',
    displayName: '修改变量',
    isControl: false,
    isControlEnd: false,
    comment: '修改变量 ${varKey} 值为 ${varValue}',
    inputs: {
        varKey: {
            name: '',
            type: 'string',
            value: '',
            display: '',
            addConfig: {
                label: '要修改的变量',
                required: true,
                type: 'variable'
            }
        },
        varValue: {
            name: '变量值',
            value: '',
            type: 'object',
            enableExpression: true,
            addConfig: {
                label: '变量值',
                type: 'object',
                defaultValue: ''
            }
        }
    },
    outputs: {},
    toCode(directive, block) {
        return __awaiter(this, void 0, void 0, function* () {
            const name = directive.inputs.varKey.value;
            let varValue = directive.inputs.varValue;
            return `${name} = await robotUtil.system.dataProcessing.modificationVariable({"varValue": ${(0, commonUtil_1.typeToCode)(varValue)}},${block});`;
        });
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ varValue }) {
        return varValue;
    });
};
exports.impl = impl;
