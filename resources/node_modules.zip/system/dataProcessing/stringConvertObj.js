"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'dataProcessing.stringConvertObj',
    displayName: 'JSON字符串转对象',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '将JSON字符串${jsonContent}转换为对象,并输出到变量${jsonObj}',
    inputs: {
        jsonContent: {
            name: 'jsonContent',
            value: '',
            type: 'string',
            addConfig: {
                label: 'Json文本',
                type: 'string',
                placeholder: '请输入json文本 例如：{"name": "tuzi", "age": 18}',
                defaultValue: '',
                tip: ''
            }
        }
    },
    outputs: {
        jsonObj: {
            name: '',
            type: 'any',
            display: 'JSON对象',
            addConfig: {
                label: 'JSON对象',
                type: 'variable',
                defaultValue: 'JSON对象',
                tip: ''
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ jsonContent }) {
        const jsonObj = JSON.parse(jsonContent);
        return { jsonObj };
    });
};
exports.impl = impl;
