"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "dataProcessing.array.removeElement",
    displayName: "移除数组元素",
    comment: "数组对象${array}中,在${index}数组下标,${rmNumber}移除元素数量",
    inputs: {
        array: {
            name: "array",
            value: "",
            display: "数组对象",
            type: "variable",
            addConfig: {
                label: "数组对象",
                type: "variable",
                required: true,
            },
        },
        index: {
            name: "index",
            value: "",
            display: "数组下标",
            type: "number",
            addConfig: {
                label: "数组下标",
                type: "variable",
                defaultValue: "0",
                required: true,
            },
        },
        rmNumber: {
            name: "rmNumber",
            value: "",
            display: "移除元素数量",
            type: "number",
            addConfig: {
                label: "移除元素数量",
                placeholder: "不填写则从下标开始移除所有元素",
                type: "variable",
                defaultValue: "",
            },
        },
    },
    outputs: {},
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ array, index, rmNumber, }) {
        if (rmNumber) {
            array.splice(index, rmNumber);
        }
        else {
            array.splice(index);
        }
    });
};
exports.impl = impl;
