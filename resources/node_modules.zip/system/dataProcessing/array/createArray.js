"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "dataProcessing.array.createArray",
    displayName: "创建数组",
    comment: "创建数组结构存储数据,${array}为数组对象",
    inputs: {},
    outputs: {
        array: {
            name: "array",
            display: "数组对象",
            type: "string",
            addConfig: {
                label: "数组对象",
                type: "variable",
                defaultValue: "",
            },
        },
    },
};
const impl = function () {
    return __awaiter(this, void 0, void 0, function* () {
        return { array: new Array() };
    });
};
exports.impl = impl;
