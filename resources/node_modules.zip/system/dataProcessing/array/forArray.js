"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "dataProcessing.array.forArray",
    isControl: true,
    isLoop: true,
    isControlEnd: false,
    displayName: "循环数组",
    comment: "循环数组数据 ${array}, 输出数组值 ${value}",
    inputs: {
        array: {
            name: "array",
            value: "",
            display: "",
            type: "variable",
            addConfig: {
                required: true,
                label: "数组对象",
                placeholder: "数组对象",
                type: "variable",
                filtersType: "array",
                autoComplete: true,
            },
        },
    },
    outputs: {
        value: {
            name: "value",
            type: "string",
            display: "数组值",
            addConfig: {
                type: "variable",
                label: "数组值",
            },
        },
    },
    toCode(directive, block) {
        return __awaiter(this, void 0, void 0, function* () {
            const { array } = directive.inputs;
            const { value } = directive.outputs;
            const code = `for (const ${value.name} of await robotUtil.system.dataProcessing.array.forArray(${array.value},${block})) {`;
            return code;
        });
    },
};
const impl = function (array) {
    return __awaiter(this, void 0, void 0, function* () {
        return array.values();
    });
};
exports.impl = impl;
