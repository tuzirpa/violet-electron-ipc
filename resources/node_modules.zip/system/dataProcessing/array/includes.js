"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "dataProcessing.array.includes",
    displayName: "数组是否包含指定值",
    comment: "数组对象${array}中，是否包含${value}",
    inputs: {
        array: {
            name: "array",
            value: "",
            display: "数组对象",
            type: "string",
            addConfig: {
                label: "数组对象",
                type: "variable",
                defaultValue: "",
            },
        },
        value: {
            name: "value",
            value: "",
            display: "数组元素值",
            type: "string",
            addConfig: {
                label: "数组元素值",
                placeholder: "请输入要添加的元素值",
                type: "string",
                defaultValue: "",
                required: true,
            },
        },
    },
    outputs: {
        isInclude: {
            name: "isInclude",
            display: "数组元素是否包含指定值",
            type: "string",
            addConfig: {
                label: "是否包含指定值",
                type: "variable",
                defaultValue: "",
            },
        },
    },
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ array, value, }) {
        const isInclude = array.includes(value);
        return { isInclude };
    });
};
exports.impl = impl;
