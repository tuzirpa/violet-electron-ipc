"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "dataProcessing.array.insertElement",
    displayName: "插入数组元素",
    comment: "数组对象${array}中，在下标${index}位置插入元素${value}",
    inputs: {
        array: {
            name: "array",
            value: "",
            display: "数组对象",
            type: "string",
            addConfig: {
                label: "数组对象",
                type: "variable",
                defaultValue: "",
            },
        },
        index: {
            name: "index",
            value: "",
            display: "数组下标",
            type: "number",
            addConfig: {
                label: "数组对象",
                type: "variable",
                defaultValue: "0",
                required: true,
            },
        },
        value: {
            name: "value",
            value: "",
            display: "数组元素值",
            type: "string",
            addConfig: {
                label: "数组元素值",
                placeholder: "请输入要插入的元素值",
                type: "string",
                defaultValue: "",
                required: true,
            },
        },
    },
    outputs: {
        arrayObj: {
            name: "arrayObj",
            display: "数组对象",
            type: "string",
            addConfig: {
                label: "数组对象",
                type: "variable",
                defaultValue: "",
            },
        },
    },
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ array, index, value, }) {
        let arrayObj = array.splice(index, 0, value);
        return { arrayObj };
    });
};
exports.impl = impl;
