"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "excel.getSheet",
    displayName: "通过名称获取一个工作表",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "从${workbook}对象读取一个工作表，并保存到${sheet}。",
    inputs: {
        workbook: {
            name: "workbook",
            value: "",
            type: "variable",
            addConfig: {
                required: true,
                label: "excel对象",
                type: "variable",
                filtersType: "excel.workbook",
                autoComplete: true,
            },
        },
        sheetName: {
            name: "sheetName",
            value: "",
            type: "string",
            addConfig: {
                required: false,
                placeholder: "工作表名称,默认值为Sheet1",
                label: "工作表名称",
                type: "string",
                defaultValue: "",
                tip: "输入工作表名称，默认值为Sheet1",
            },
        },
    },
    outputs: {
        sheet: {
            name: "",
            display: "Excel工作表对象",
            type: "excel.sheet",
            addConfig: {
                label: "Excel工作表对象",
                type: "variable",
                defaultValue: "sheet",
            },
        },
    },
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ workbook, sheetName = "Sheet1", }) {
        if (!workbook.Sheets[sheetName]) {
            throw new Error(`工作表${sheetName}不存在`);
        }
        const sheet = workbook.Sheets[sheetName];
        return { sheet };
    });
};
exports.impl = impl;
