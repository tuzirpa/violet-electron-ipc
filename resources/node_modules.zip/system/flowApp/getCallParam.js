"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'flowApp.getCallParam',
    displayName: '获取调用参数',
    comment: '从流程参数${arrayObj}中取出第${index}项保存到${item}',
    inputs: {
        index: {
            name: 'index',
            value: '',
            display: '',
            type: 'number',
            addConfig: {
                required: true,
                label: '项下标（索引）',
                type: 'string'
            }
        }
    },
    outputs: {
        item: {
            name: '',
            display: '数组项数据',
            type: 'object',
            addConfig: {
                label: '对象',
                type: 'variable',
                defaultValue: 'arrayItem'
            }
        }
    },
    toCode(directive, block) {
        return __awaiter(this, void 0, void 0, function* () {
            const { index } = directive.inputs;
            const { item } = directive.outputs;
            return `var {item: ${item.name}} = await robotUtil.system.flowApp.getCallParam({arrayObj: _callParams,index: ${index.value} },${block})`;
        });
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ arrayObj, index }) {
        if (!Array.isArray(arrayObj)) {
            throw new Error('选择的对象不是数组');
        }
        if (index < 1 || index > arrayObj.length) {
            throw new Error('数组索引超出范围');
        }
        const item = arrayObj[index - 1];
        return { item };
    });
};
exports.impl = impl;
