"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const axios_1 = __importDefault(require("axios"));
const config = {
    name: "network.httpRequest",
    sort: 2,
    displayName: "http请求",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "发起http请求,请求方法为${method}",
    inputs: {
        method: {
            name: "method",
            value: "",
            display: "",
            type: "string",
            addConfig: {
                label: "请求方法",
                required: true,
                type: "select",
                options: [
                    {
                        label: "GET",
                        value: "GET",
                    },
                    {
                        label: "POST",
                        value: "POST",
                    },
                ],
                defaultValue: "GET",
            },
        },
        url: {
            name: "url",
            value: "",
            display: "",
            type: "string",
            addConfig: {
                label: "URL",
                required: true,
                type: "string",
                placeholder: "请输入URL",
            },
        },
        protocolHeader: {
            name: "protocolHeader",
            value: "",
            display: "",
            type: "textarea",
            addConfig: {
                label: "协议头",
                type: "textarea",
                placeholder: `设置请求协议头，例如：
        Accept: application/json, text/plain, */*
        Accept-Encoding: gzip, deflate, br, zstd
        Accept-Language: zh-CN,zh;q=0.9
        Cache-Control: no-cache
        `,
                defaultValue: "",
            },
        },
        protocolBody: {
            name: "protocolBody",
            value: "",
            display: "",
            type: "textarea",
            addConfig: {
                label: "协议体",
                type: "textarea",
                placeholder: "提交的数据体",
                filters: "this.inputs.method.value == 'POST'",
            },
        },
    },
    outputs: {
        resResult: {
            name: "",
            display: "请求结果",
            type: "string",
            addConfig: {
                label: "请求结果",
                type: "variable",
                defaultValue: "resResult",
            },
        },
    },
};
exports.config = config;
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ method, url, protocolHeader, protocolBody, }) {
        let headers;
        if (protocolHeader) {
            headers = protocolHeader.split("\n").reduce((acc, cur) => {
                const [key, value] = cur.split(": ");
                if (key && value) {
                    acc[key.trim()] = value.trim();
                }
                return acc;
            }, {});
        }
        const resResult = yield (0, axios_1.default)({
            method: method,
            url: url,
            data: protocolBody,
            headers: headers,
        });
        return { resResult: resResult.data };
    });
};
exports.impl = impl;
