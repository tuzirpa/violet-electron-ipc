"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'text.interceptText',
    icon: 'icon-web-create',
    displayName: '截取文本内容',
    comment: '',
    inputs: {
        text: {
            name: 'text',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '原始文本',
                placeholder: '原始文本',
                type: 'textarea',
                required: true
            }
        },
        startPos: {
            name: 'startPos',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '起始位置',
                placeholder: '起始位置',
                type: 'select',
                required: true,
                options: [
                    { label: '从第一个字符开始截取', value: '0' },
                    { label: '从指定位置开始截取', value: '-1' },
                    { label: '从指定文本开始截取', value: '-2' }
                ],
                defaultValue: '0'
            }
        },
        startIndex: {
            name: 'startIndex',
            value: '',
            display: '',
            type: 'number',
            addConfig: {
                label: '起始字符的位置',
                placeholder: '请输入起始字符的位置',
                type: 'variable',
                defaultValue: '0',
                filters: "this.inputs.startPos.value === '-1'"
            }
        },
        startText: {
            name: 'startText',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '起始文本',
                placeholder: '请输入起始文本的内容',
                type: 'variable',
                defaultValue: '',
                filters: "this.inputs.startPos.value === '-2'"
            }
        },
        interceptWay: {
            name: 'interceptWay',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '截取方式',
                type: 'select',
                options: [
                    {
                        label: '截取到最后一个字符',
                        value: 'end'
                    },
                    {
                        label: '截取到指定长度',
                        value: 'custom'
                    }
                ],
                defaultValue: 'end'
            }
        },
        interceptLength: {
            name: 'interceptLength',
            value: '',
            display: '',
            type: 'number',
            addConfig: {
                label: '截取长度',
                type: 'variable',
                defaultValue: '0'
            }
        }
    },
    outputs: {
        subText: {
            name: '',
            display: '保存结果至',
            type: 'string',
            addConfig: {
                label: '保存结果至',
                type: 'variable',
                defaultValue: 'subText'
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ text, startPos, startIndex, startText, interceptWay, interceptLength }) {
        let start = startPos === '-1' ? startIndex : startPos === '-2' ? text.indexOf(startText) : 0;
        let end = interceptWay === 'end' ? text.length - 1 : start + interceptLength;
        let subText = text.substring(start, end + 1);
        return { subText };
    });
};
exports.impl = impl;
