"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//动态导入当前目录下所有js文件，并将其导出为一个对象
const require_dir_1 = __importDefault(require("require-dir"));
const fs_1 = __importDefault(require("fs"));
const modules = (0, require_dir_1.default)("./", {
    filter: function (fullPath) {
        const stat = fs_1.default.statSync(fullPath);
        if (stat.isDirectory()) {
            return true;
        }
        return fullPath.endsWith(".js");
    },
    recurse: true,
});
function loadModule(module) {
    for (let key in module) {
        if (module.hasOwnProperty(key)) {
            const tModule = module[key];
            const config = tModule.config;
            if (config && config.name) {
                //xxx.yyy
                const keys = config.key || config.name;
                const namespace = keys.split(".");
                let t1, t2;
                const configName = namespace.pop();
                namespace.forEach((name, index) => {
                    if (index === 0) {
                        t1 = exports[name] || {};
                        exports[name] = t1;
                    }
                    else {
                        t1[name] = t1[name] || {};
                        t2 = t1[name];
                        t1 = t2;
                    }
                });
                t1[configName] = tModule.impl;
            }
            else {
                loadModule(tModule);
            }
        }
    }
}
loadModule(modules);
