"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const config = {
    name: 'web.keyboard.sendCharacter',
    sort: 2,
    displayName: '发送字符',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '往页面 ${page} 发送字符 ${char}',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '网页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        char: {
            name: 'char',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '发送的字符',
                required: true,
                placeholder: '请输入要发送的字符',
                type: 'textarea'
            }
        }
    },
    outputs: {}
};
exports.config = config;
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ page, char }) {
        yield page.keyboard.sendCharacter(char);
    });
};
exports.impl = impl;
