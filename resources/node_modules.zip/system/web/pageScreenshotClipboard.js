"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const os_1 = __importDefault(require("os"));
exports.config = {
    name: 'web.pageScreenshotClipboard',
    icon: 'icon-web-create',
    displayName: '页面中元素截图至剪贴板',
    comment: '在页面${browserPage}中选中元素${selector}，并对其进行截图至剪贴板',
    inputs: {
        browserPage: {
            name: 'browserPage',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        selector: {
            name: 'selector',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: 'css选择器',
                placeholder: '不填写则默认截取整个页面',
                type: 'string',
                defaultValue: '',
                tip: '不填写则默认截取整个页面'
            }
        }
    },
    outputs: {}
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ browserPage, selector }) {
        const tmpFile = os_1.default.tmpdir() + '/' + new Date().getTime() + '.png';
        if (selector) {
            const fileElement = yield browserPage.waitForSelector(selector);
            if (fileElement) {
                yield fileElement.screenshot({
                    type: 'png',
                    path: tmpFile
                });
            }
        }
        else {
            yield browserPage.screenshot({
                fullPage: true,
                type: 'png',
                path: tmpFile
            });
        }
        console.log('截图保存成功！');
    });
};
exports.impl = impl;
