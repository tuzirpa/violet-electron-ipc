"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "web.closeBrowser",
    displayName: "关闭浏览器",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "关闭浏览器 ${browser}",
    inputs: {
        browser: {
            name: "browser",
            value: "",
            display: "",
            type: "variable",
            addConfig: {
                label: "浏览器对象",
                type: "variable",
                filtersType: "web.browser",
                autoComplete: true,
            },
        },
    },
    outputs: {},
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ browser }) {
        yield browser.close();
        console.log("Browser closed");
    });
};
exports.impl = impl;
