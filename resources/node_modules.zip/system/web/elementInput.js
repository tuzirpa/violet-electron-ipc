"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const config = {
    name: "web.elementInput",
    sort: 2,
    displayName: "填写输入框",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "在元素${element}上输入${content}",
    inputs: {
        element: {
            name: "element",
            value: "",
            display: "",
            type: "variable",
            addConfig: {
                label: "网页对象",
                type: "variable",
                filtersType: "web.Element",
                autoComplete: true,
            },
        },
        content: {
            name: "content",
            value: "",
            type: "string",
            addConfig: {
                label: "输入的内容",
                type: "string",
            },
        },
    },
    outputs: {},
};
exports.config = config;
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ element, content, }) {
        yield element.type(content);
    });
};
exports.impl = impl;
//# sourceMappingURL=elementInput.js.map