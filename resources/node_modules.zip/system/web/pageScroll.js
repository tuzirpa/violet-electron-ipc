"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.pageScroll',
    displayName: '页面滚动',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '在标签${page}中,滚动到页面底部，每次滚动${scrollDistance}距离，间隔${scrollDelay}毫秒',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        scrollDistance: {
            name: 'scrollDistance',
            value: '100',
            display: '每次滚动距离',
            type: 'number',
            addConfig: {
                label: '每次滚动距离',
                type: 'variable',
                autoComplete: true,
                required: true,
                defaultValue: '100'
            }
        },
        scrollDelay: {
            name: 'scrollDelay',
            value: '600',
            display: '滚动延迟',
            type: 'number',
            addConfig: {
                label: '滚动延迟',
                type: 'variable',
                autoComplete: true,
                defaultValue: '600'
            }
        }
    },
    outputs: {}
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ page, scrollDistance, scrollDelay }) {
        // 获取页面的总高度
        let pageHeight = yield page.evaluate(() => document.body.scrollHeight);
        let currentPosition = 0;
        while (currentPosition < pageHeight) {
            // 滚动页面
            yield page.evaluate((scrollDistance) => {
                window.scrollBy({ left: 0, top: scrollDistance, behavior: 'smooth' });
            }, scrollDistance);
            currentPosition += scrollDistance;
            pageHeight = yield page.evaluate(() => document.body.scrollHeight);
            console.log('页面滚动中...', `currentPosition: ${currentPosition}, pageHeight: ${pageHeight}`);
            // 等待一段时间再进行下一次滚动
            yield new Promise((resolve) => setTimeout(resolve, scrollDelay));
        }
    });
};
exports.impl = impl;
