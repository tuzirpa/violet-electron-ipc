"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.getElement_xy',
    sort: 2,
    displayName: '获取元素的坐标',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '获取元素${element}的坐标, 返回坐标对象${coordinate}',
    inputs: {
        element: {
            name: 'element',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                required: true,
                label: '元素对象',
                type: 'variable',
                filtersType: 'web.Element',
                autoComplete: true
            }
        }
    },
    outputs: {
        coordinate: {
            name: '',
            display: '坐标对象',
            type: 'web.coordinate',
            typeDetails: [
                {
                    key: 'x',
                    type: 'number',
                    display: 'X坐标'
                },
                {
                    key: 'y',
                    type: 'number',
                    display: 'X坐标'
                },
                {
                    key: 'width',
                    type: 'number',
                    display: '宽度'
                },
                {
                    key: 'height',
                    type: 'number',
                    display: '高度'
                }
            ],
            addConfig: {
                label: '坐标对象',
                type: 'variable',
                defaultValue: 'coordinate'
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ element }) {
        const coordinate = yield element.boundingBox();
        const coordinateOut = {
            x: coordinate === null || coordinate === void 0 ? void 0 : coordinate.x,
            y: coordinate === null || coordinate === void 0 ? void 0 : coordinate.y,
            width: coordinate === null || coordinate === void 0 ? void 0 : coordinate.width,
            height: coordinate === null || coordinate === void 0 ? void 0 : coordinate.height
        };
        return { coordinate: coordinateOut };
    });
};
exports.impl = impl;
