"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "web.clearAllCookie",
    icon: "icon-web-create",
    displayName: "清除所有cookie",
    comment: "在页面${browserPage}中清理所有的cookie",
    inputs: {
        browserPage: {
            name: "browserPage",
            value: "",
            display: "",
            type: "variable",
            addConfig: {
                required: true,
                label: "标签页对象",
                placeholder: "选择标签页对象",
                type: "variable",
                filtersType: "web.page",
                autoComplete: true,
            },
        },
    },
    outputs: {},
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ browserPage }) {
        let cookies = yield browserPage.cookies();
        cookies.forEach((cookie) => __awaiter(this, void 0, void 0, function* () {
            yield browserPage.deleteCookie(cookie);
        }));
    });
};
exports.impl = impl;
