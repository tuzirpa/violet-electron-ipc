const fs = require("fs");
const puppeteer = require("puppeteer");

exports.config = {
	name: "web.create",
	displayName: "创建浏览器",
	icon: "icon-web-create",
	isControl: false,
	isControlEnd: false,
	comment: "启动${webType},保存至：${browser}",
	inputs: {
		webType: {
			name: "webType",
			value: "",
			display: "内置浏览器",
			type: "string",
			addConfig: {
				required: true,
				label: "浏览器类型",
				type: "select",
				options: [
					{
						label: "内置浏览器",
						value: "tuziChrome",
					},
					{
						label: "谷歌浏览器",
						value: "chrome",
					},
					{
						label: "Edge",
						value: "edge",
					},
				],
				defaultValue: "tuziChrome",
				tip: "选择浏览器类型",
			},
		},
		url: {
			name: "url",
			value: "",
			type: "string",
			addConfig: {
				label: "地址",
				type: "string",
				required: true,
				defaultValue: "https://",
				tip: "打开的地址",
			},
		},
		loadTimeout: {
			name: "timeout",
			value: "30",
			type: "number",
			addConfig: {
				label: "超时",
				type: "string",
				isAdvanced: true,
				required: true,
				defaultValue: "30",
				tip: "超时时间，单位：秒",
			},
		},
	},
	outputs: {
		browser: {
			name: "",
			display: "浏览器对象",
			type: "web.browser",
			addConfig: {
				label: "浏览器对象",
				type: "variable",
				defaultValue: "web_browser",
			},
		},
		page: {
			name: "",
			display: "标签页对象",
			type: "web.page",
			addConfig: {
				label: "浏览器对象",
				type: "variable",
				defaultValue: "page",
			},
		},
	},
};

function regQueryExeCutablePath(regPath) {
	return (
		new Promise() <
		string >
		((resolve, reject) => {
			child_process.exec(
				`REG QUERY "${regPath}"`,
				function (error, stdout, _stderr) {
					if (error != null) {
						reject(error);
						return;
					}
					const exePath = stdout.substring(
						stdout.indexOf("REG_SZ") + 6,
						stdout.indexOf(",")
					);
					const ep = exePath.trim().replace(/\\/g, "/");
					resolve(ep);
				}
			);
		})
	);
}

async function getExeCutablePath(type) {
	//读取注册表获取浏览器路径
	let path = "";
	switch (type) {
		case "chrome":
			//读取windows注册表 HKEY_LOCAL_MACHINE\SOFTWARE\Clients\StartMenuInternet\Google Chrome\DefaultIcon
			path = await regQueryExeCutablePath(
				"HKEY_LOCAL_MACHINE\\SOFTWARE\\Clients\\StartMenuInternet\\Google Chrome\\DefaultIcon"
			);
			break;
		case "edge":
			//HKEY_LOCAL_MACHINE\SOFTWARE\Clients\StartMenuInternet\Microsoft Edge\DefaultIcon
			path = await regQueryExeCutablePath(
				"HKEY_LOCAL_MACHINE\\SOFTWARE\\Clients\\StartMenuInternet\\Microsoft Edge\\DefaultIcon"
			);
			break;
		default:
			break;
	}
	return path;
}

exports.impl = async function (params, _block) {
	const { webType: type, url: webUrl, loadTimeout } = params;
	let executablePath = "";
	if (type !== "tuziChrome") {
		executablePath = await getExeCutablePath(type);
		// if (executablePath === '') {
		//     sendLog('error', `本地未安装 ${displayName}，请设置先安装 ${displayName}`, block);
		//     throw new Error('未设置chrome路径');
		// }
	}
	const ops = { headless: false, defaultViewport: null };
	executablePath && (ops.executablePath = executablePath);
	const browser = await puppeteer.launch(ops);
	const pages = await browser.pages();
	const page = pages[0];
	await page.goto(webUrl, { timeout: loadTimeout * 1000 });
	return { browser, page };
};
