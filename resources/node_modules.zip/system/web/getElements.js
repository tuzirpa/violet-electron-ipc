"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.getElements',
    icon: 'icon-web-create',
    displayName: '获取相似元素',
    comment: '在页面${browserPage}中获取 ${selector} 匹配的元素，元素列表保存到${elements},元素个数保存到${elementCount}',
    inputs: {
        browserPage: {
            name: 'browserPage',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签页对象',
                placeholder: '选择标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        selector: {
            name: 'iframeSrc',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: 'css或者xpath选择器',
                placeholder: "请输入css选择器或xpath选择器 xpath 示例：//*[@id='test']",
                elementLibrarySupport: true,
                type: 'textarea'
            }
        }
    },
    outputs: {
        elements: {
            name: '',
            display: '数组-元素列表',
            type: 'array',
            addConfig: {
                label: '元素列表',
                type: 'variable',
                defaultValue: 'elements'
            }
        },
        elementCount: {
            name: '',
            display: '数字-元素个数',
            type: 'number',
            addConfig: {
                label: '元素个数',
                type: 'variable',
                defaultValue: 'elementCount'
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ browserPage, selector }) {
        if (selector.startsWith('//')) {
            selector = `::-p-xpath(${selector})`;
        }
        const elements = yield browserPage.$$(selector);
        return { elements, elementCount: elements.length };
    });
};
exports.impl = impl;
