"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.pageGeneratePdf',
    icon: 'icon-web-create',
    displayName: '页面生成PDF',
    comment: '将页面${browserPage} 生成PDF文件，并保存到本地${fileSavePath}。',
    inputs: {
        browserPage: {
            name: 'browserPage',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        fileSavePath: {
            name: 'fileSavePath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '文件保存路径',
                placeholder: '选择要文件保存路径',
                type: 'filePath',
                defaultValue: '',
                required: true,
                openDirectory: true,
                tip: '文件保存路径'
            }
        }
    },
    outputs: {}
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ browserPage, fileSavePath }) {
        let filePath = fileSavePath + '/' + new Date().getTime() + '.pdf';
        console.log('开始生成PDF文件...');
        console.log(filePath);
        console.log(browserPage);
        yield browserPage.pdf({
            format: 'a4', //打印背景,默认为false
            printBackground: true, //不展示页眉
            displayHeaderFooter: true, //页眉与页脚样式,可在此处展示页码等
            path: filePath
        });
        console.log('PDF文件保存成功！');
    });
};
exports.impl = impl;
