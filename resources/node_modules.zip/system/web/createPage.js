"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "web.createPage",
    displayName: "创建标签页",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "在浏览器${browserPage}中创建标签页,保存至：${page}",
    inputs: {
        browserPage: {
            name: "browserPage",
            value: "",
            display: "",
            type: "variable",
            addConfig: {
                label: "浏览器对象",
                type: "variable",
                filtersType: "web.browser",
                autoComplete: true,
            },
        },
    },
    outputs: {
        page: {
            name: "",
            display: "标签页对象",
            type: "web.page",
            addConfig: {
                label: "标签页对象",
                type: "variable",
                defaultValue: "page",
            },
        },
    },
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ browserPage }) {
        const page = yield browserPage.newPage();
        return { page };
    });
};
exports.impl = impl;
