"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "web.pageExecuteScript",
    icon: "icon-web-create",
    displayName: "页面中执行JavaScript脚本",
    comment: "在页面${browserPage}中执行JavaScript脚本",
    inputs: {
        browserPage: {
            name: "browserPage",
            value: "",
            display: "",
            type: "variable",
            addConfig: {
                label: "浏览器对象",
                type: "variable",
                filtersType: "web.page",
                autoComplete: true,
            },
        },
        script: {
            name: "script",
            value: "",
            display: "脚本内容",
            type: "string",
            addConfig: {
                label: "脚本内容",
                type: "textarea",
                defaultValue: "",
                required: true,
                tip: "需要执行的JavaScript脚本",
            },
        },
    },
    outputs: {
        scriptResult: {
            name: "",
            display: "javascript脚本执行结果",
            type: "string",
            addConfig: {
                label: "javascript脚本执行结果",
                type: "variable",
                defaultValue: "scriptResult",
                required: true,
                tip: "javascript脚本执行结果",
            },
        },
    },
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ browserPage, script, }) {
        const scriptResult = yield browserPage.evaluate(script);
        return { scriptResult };
    });
};
exports.impl = impl;
