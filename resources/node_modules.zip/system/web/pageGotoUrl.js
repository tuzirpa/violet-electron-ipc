"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.pageGotoUrl',
    displayName: '访问网页地址',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '在标签${page}中访问网页地址${url},超时等待时间${loadTimeout}秒',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        url: {
            name: 'url',
            value: '',
            type: 'string',
            addConfig: {
                label: '地址',
                type: 'textarea',
                placeholder: '网页地址：如 https://www.baidu.com ',
                required: true,
                defaultValue: '',
                tip: '打开的地址'
            }
        },
        loadTimeout: {
            name: 'timeout',
            value: '',
            type: 'number',
            addConfig: {
                label: '等待页面加载超时',
                placeholder: '不填或0表示不等待页面加载完成',
                type: 'string',
                defaultValue: '',
                tip: '等待超时时间，单位：秒 | 不填或者填0表示不等待'
            }
        }
    },
    outputs: {}
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ page, url, loadTimeout }) {
        if (loadTimeout > 0) {
            yield page.goto(url, { timeout: loadTimeout * 1000 });
        }
        else {
            page.goto(url, { timeout: 0 });
        }
        return { page };
    });
};
exports.impl = impl;
