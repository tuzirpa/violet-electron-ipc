"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "web.mouseDragAndDrop",
    icon: "icon-web-create",
    displayName: "鼠标拖动并释放",
    comment: "在页面${page}中, 鼠标拖动并释放, 从(${startX}, ${startY})到(${endX}, ${endY}), 延迟${delay}毫秒",
    inputs: {
        page: {
            name: "page",
            value: "",
            display: "",
            type: "variable",
            addConfig: {
                label: "标签页对象",
                type: "variable",
                filtersType: "web.page",
                autoComplete: true,
            },
        },
        startX: {
            name: "startX",
            value: "",
            display: "",
            type: "number",
            addConfig: {
                label: "拖动起点X坐标",
                type: "string",
            },
        },
        startY: {
            name: "startY",
            value: "",
            display: "",
            type: "number",
            addConfig: {
                label: "拖动起点Y坐标",
                type: "string",
            },
        },
        endX: {
            name: "endX",
            value: "",
            display: "",
            type: "number",
            addConfig: {
                label: "拖动结束点X坐标",
                type: "string",
            },
        },
        endY: {
            name: "endY",
            value: "",
            display: "",
            type: "number",
            addConfig: {
                label: "拖动结束点Y坐标",
                type: "string",
            },
        },
        delay: {
            name: "delay",
            value: "",
            display: "",
            type: "number",
            addConfig: {
                label: "延迟",
                type: "string",
                defaultValue: "0",
            },
        },
    },
    outputs: {},
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ page, startX, startY, endX, endY, delay, }) {
        const start = { x: startX, y: startY };
        const target = { x: endX, y: endY };
        yield page.mouse.dragAndDrop(start, target, { delay: delay });
        console.log("鼠标拖动并释放成功");
    });
};
exports.impl = impl;
