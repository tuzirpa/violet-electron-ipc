"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.mouseDown',
    icon: 'icon-web-create',
    displayName: '按下鼠标',
    comment: '在页面${page}中, 按下鼠标${button}键',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        button: {
            name: 'button',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '选择鼠标按钮',
                type: 'select',
                defaultValue: 'left',
                options: [
                    { label: '左键', value: 'left' },
                    { label: '右键', value: 'right' },
                    { label: '中键', value: 'middle' },
                    { label: '后退键', value: 'back' },
                    { label: '前进键', value: 'forward' }
                ]
            }
        }
    },
    outputs: {
        key: {
            name: 'key',
            display: '按下鼠标的键',
            type: 'web.mouseButton',
            addConfig: {
                label: '按下鼠标的键',
                type: 'variable',
                defaultValue: ''
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ page, button }) {
        console.log('按下鼠标键', button);
        yield page.mouse.down({ button });
        return { key: button };
    });
};
exports.impl = impl;
