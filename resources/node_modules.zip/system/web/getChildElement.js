"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "web.getChildElement",
    sort: 2,
    displayName: "获取元素的子元素",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "在元素${element}下查找子元素${selector}，并保存到变量${childElement}中。",
    inputs: {
        element: {
            name: "element",
            value: "",
            display: "",
            type: "variable",
            addConfig: {
                required: true,
                label: "元素对象",
                type: "variable",
                filtersType: "web.Element",
                autoComplete: true,
            },
        },
        selector: {
            name: "selector",
            value: "",
            display: "",
            type: "string",
            addConfig: {
                required: true,
                label: "CSS选择器",
                type: "string",
            },
        },
        timeout: {
            name: "timeout",
            value: "",
            type: "number",
            addConfig: {
                isAdvanced: true,
                label: "超时时间",
                type: "string",
                defaultValue: 30,
            },
        },
    },
    outputs: {
        childElement: {
            name: "",
            display: "元素对象",
            type: "web.Element",
            addConfig: {
                label: "元素对象",
                type: "variable",
                defaultValue: "childElement",
            },
        },
    },
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ element, selector, timeout, }) {
        const childElement = yield element.waitForSelector(selector, {
            timeout: timeout * 1000,
        });
        return { childElement };
    });
};
exports.impl = impl;
