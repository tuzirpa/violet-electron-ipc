"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.nextPort = nextPort;
exports.getAvailablePort = getAvailablePort;
exports.checkPort = checkPort;
const node_net_1 = require("node:net");
function nextPort(port) {
    return port + 1;
}
function getAvailablePort() {
    return __awaiter(this, arguments, void 0, function* (port = 3000) {
        if (port < 1 || port > 65535) {
            throw new Error('无可用的端口');
        }
        const _port = yield checkPort(port);
        if (_port) {
            return _port;
        }
        else {
            console.debug(`端口 ${port} 被占用，尝试下一个...`);
            return getAvailablePort(nextPort(port));
        }
    });
}
function checkPort(port) {
    return new Promise((resolve, _reject) => {
        // 启动个服务，使用指定端口
        const server = (0, node_net_1.createServer)(() => { });
        // 即使服务器正在监听，但它不会阻止程序退出
        server.unref();
        function onListen() {
            server.close();
            resolve(port);
        }
        server.once('listening', onListen);
        server.on('error', (_e) => {
            resolve(false);
        });
        server.listen(port, '127.0.0.1');
    });
}
