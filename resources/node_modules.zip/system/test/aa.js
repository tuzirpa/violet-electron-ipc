"use strict";
// const puppeteer = require('puppeteer-core');
// (async () => {
//     const browser = await puppeteer.connect({
//         browserURL: 'http://localhost:11922',
//         defaultViewport: null
//     });
//     const pages = await browser.pages();
//     const page = pages[0];
//     // await                       ::-p-xpath(//*[@id="1"]/div/div/div[3]/div[1]/div)
//     const qq = '//*[@id="1"]/div/div/div[3]/div[1]/div';
//     const element = await page.$$(`::-p-xpath(${qq})`);
//     console.log(element);
//     console.log(element.length);
//     browser.disconnect();
// })();
