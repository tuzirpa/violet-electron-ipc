const fs = require("fs");
const readline = require("readline");

function typeToCode(inputItem) {
    if (inputItem.type === 'string') {
        return `String(\`${inputItem.value}\`)`;
    } else if (inputItem.type === 'number') {
        return `Number(String(\`${inputItem.value}\`))`;
    } else if (inputItem.type === 'boolean') {
        return `String(\`${inputItem.value}\`).toLowerCase() == 'true'`;
    }
    return '';
}


exports.config = {
	name: "file.readLine",
	displayName: "读取文件-按行读取",
	icon: "icon-web-create",
	isControl: true,
	isControlEnd: false,
	comment: "读取文件${filePath} 行内容保存到 ${fileLineContent}",
	inputs: {
		filePath: {
			name: "文件路径",
			value: "",
			type: "string",
			addConfig: {
				label: "文件路径",
				type: "filePath",
				defaultValue: "",
				tip: "选择一个文件路径",
			},
		},
	},
	outputs: {
		fileLineContent: {
			name: "fileLineContent",
			display: "文本（文件内容）",
			type: "string",
			addConfig: {
				label: "文件内容",
				type: "variable",
				defaultValue: "fileLineContent",
			},
		},
	},
	async toCode(directive, block) {
		const filePath = directive.inputs.filePath;
		const { fileLineContent } = directive.outputs;

		return `for await (let ${ fileLineContent.name } of await robotUtil.extend.file.readLine(${typeToCode(filePath)},${block})) {`;
	},
};

exports.impl = async function ({ filePath }) {
	let rl = readline.createInterface({
		input: fs.createReadStream(filePath),
	});
	return rl;
};
