//动态导入当前目录下所有js文件，并将其导出为一个对象
const requireDir = require("require-dir");
const modules = requireDir("./", {
	filter: function (fullPath) {
		return fullPath.endsWith(".js");
	},
});

for (let key in modules) {
	if (modules.hasOwnProperty(key)) {
		const config = modules[key].config;
		if (config && config.name) {
			//xxx.yyy

			const namespace = config.name.split(".");
			const configName = namespace.pop();
			//exports.xxx.yyy
			let lastName = "";
			namespace.forEach((name) => {
				lastName = name;
				exports[name] = exports[name] || {};
			});

			exports[lastName][configName] = modules[key].impl;
		}
	}
}
