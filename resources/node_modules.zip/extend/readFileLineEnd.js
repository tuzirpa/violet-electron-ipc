const fs = require("fs");

exports.config = {
	name: "file.readLineEnd",
	displayName: "读取文件-行尾",
	icon: "icon-web-create",
	isControl: false,
	isControlEnd: true,
	comment: "按行读取结束符",
	inputs: {},
	outputs: {},
	async toCode(directive, block) {
		return `}`;
	},
};

exports.impl = async function () {};
