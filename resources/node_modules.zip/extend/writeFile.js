const fs = require("fs");
const log = require("tuzirobot/log");

exports.config = {
	name: "file.write",
	displayName: "写入文件",
	icon: "icon-web-create",
	isControl: false,
	isControlEnd: false,
	comment: "写入 ${content}到文件 ${filwPath}",
	inputs: {
		filePath: {
			name: "文件路径",
			value: "",
			type: "string",
			addConfig: {
				label: "文件路径",
				type: "filePath",
				defaultValue: "",
				tip: "选择一个文件路径",
			},
		},
		content: {
			name: "写入内容",
			value: "",
			type: "string",
			addConfig: {
				label: "写入内容",
				type: "string",
				defaultValue: ""
			}
		},
	},
	outputs:{}
};

exports.impl = async function ({ filePath,content }, block) {
	console.log(`写入文件${filePath} 内容${content}`);
};
