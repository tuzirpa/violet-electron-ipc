const fs = require("fs");

exports.config = {
	name: "file.read",
	displayName: "读取文件",
	icon: "icon-web-create",
	isControl: false,
	isControlEnd: false,
	comment: "读取文件${filePath} 保存到 ${fileContent}",
	inputs: {
		filePath: {
			name: "文件路径",
			value: "",
			type: "string",
			addConfig: {
				label: "文件路径",
				type: "filePath",
				defaultValue: "",
				tip: "选择一个文件路径",
			},
		},
	},
	outputs: {
		fileContent: {
			name: "fileContent",
			display: "文本（文件内容）",
			type: "string",
			addConfig: {
				label: "文件内容",
				type: "variable",
				defaultValue: "fileContent",
			},
		},
	},
};

exports.impl = async function ({ filePath }) {
	const fileContent = fs.readFileSync(filePath, "utf-8");
	console.log(`读取文件${filePath},内容：${fileContent}`);
	return { fileContent };
};
